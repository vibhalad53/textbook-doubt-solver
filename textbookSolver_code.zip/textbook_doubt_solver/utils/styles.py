"""Custom CSS for a clean blue / white / light-grey study dashboard."""

CUSTOM_CSS = """
<style>
:root {
    --blue-900: #1e3a8a;
    --blue-700: #1d4ed8;
    --blue-600: #2563eb;
    --blue-100: #dbeafe;
    --blue-50:  #eff6ff;
    --grey-50:  #f5f7fb;
    --grey-200: #e5e7eb;
    --grey-600: #4b5563;
    --text:     #1f2937;
}

.stApp { background: var(--grey-50); }
.block-container { padding-top: 1.6rem; max-width: 1050px; }

/* ---------- Hero header ---------- */
.hero {
    background: linear-gradient(120deg, var(--blue-900) 0%, var(--blue-600) 100%);
    color: #ffffff;
    border-radius: 18px;
    padding: 1.6rem 2rem;
    margin-bottom: 1.4rem;
    box-shadow: 0 8px 24px rgba(30, 58, 138, 0.18);
}
.hero h1 { color: #ffffff; font-size: 2.1rem; margin: 0; font-weight: 700; }
.hero p  { color: #dbeafe; font-size: 1.05rem; margin: 0.35rem 0 0 0; }
.hero .badge {
    display: inline-block; margin-top: 0.8rem; margin-right: 0.4rem;
    background: rgba(255,255,255,0.16); color: #ffffff;
    border: 1px solid rgba(255,255,255,0.28);
    border-radius: 999px; padding: 0.15rem 0.75rem; font-size: 0.8rem;
}

/* ---------- Cards ---------- */
.card {
    background: #ffffff;
    border: 1px solid var(--grey-200);
    border-radius: 14px;
    padding: 1rem 1.3rem;
    margin-bottom: 1rem;
    box-shadow: 0 2px 8px rgba(17, 24, 39, 0.04);
}
.card h3 { margin: 0 0 0.3rem 0; color: var(--blue-900); font-size: 1.1rem; }
.muted { color: var(--grey-600); font-size: 0.92rem; }

.doc-pill {
    display: flex; align-items: center; gap: 0.8rem; flex-wrap: wrap;
    background: var(--blue-50); border: 1px solid var(--blue-100);
    border-radius: 12px; padding: 0.7rem 1rem; margin: 0.4rem 0 1rem 0;
}
.doc-pill .name { font-weight: 600; color: var(--blue-900); }
.doc-pill .stat {
    background: #ffffff; border: 1px solid var(--blue-100); border-radius: 999px;
    padding: 0.1rem 0.65rem; font-size: 0.82rem; color: var(--blue-700);
}
.doc-pill .ok { color: #15803d; font-weight: 600; font-size: 0.88rem; }

/* ---------- Source quotation box ---------- */
.source-box {
    background: var(--blue-50);
    border-left: 5px solid var(--blue-600);
    border-radius: 10px;
    padding: 0.8rem 1rem;
    margin-top: 0.6rem;
}
.source-box .label {
    font-size: 0.75rem; letter-spacing: 0.06em; text-transform: uppercase;
    color: var(--blue-700); font-weight: 700; margin-bottom: 0.3rem;
}
.source-box blockquote {
    margin: 0; padding: 0; border: none; font-style: italic; color: var(--text);
}
.source-box .page {
    display: inline-block; margin-top: 0.55rem;
    background: var(--blue-600); color: #ffffff; border-radius: 999px;
    padding: 0.1rem 0.7rem; font-size: 0.8rem; font-weight: 600;
}
.source-box .note { font-size: 0.78rem; color: var(--grey-600); margin-left: 0.5rem; }

.simple-tag {
    display: inline-block; background: #dcfce7; color: #166534;
    border-radius: 999px; padding: 0.1rem 0.7rem; font-size: 0.78rem;
    font-weight: 600; margin-bottom: 0.4rem;
}

/* ---------- Chat bubbles ---------- */
[data-testid="stChatMessage"] {
    background: #ffffff;
    border: 1px solid var(--grey-200);
    border-radius: 14px;
    padding: 0.8rem 1rem;
    margin-bottom: 0.7rem;
}

/* ---------- Buttons ---------- */
.stButton > button {
    border-radius: 10px; font-weight: 600;
    border: 1px solid var(--blue-600);
}
.stButton > button[kind="primary"] { background: var(--blue-600); color: #ffffff; }
.stButton > button[kind="primary"]:hover { background: var(--blue-700); }

/* ---------- Sidebar ---------- */
[data-testid="stSidebar"] { background: #ffffff; border-right: 1px solid var(--grey-200); }
.side-title { color: var(--blue-900); font-weight: 700; font-size: 1.05rem; margin-bottom: 0.2rem; }
.info-table td { padding: 0.12rem 0.4rem 0.12rem 0; font-size: 0.88rem; vertical-align: top; }
.info-table td:first-child { color: var(--grey-600); white-space: nowrap; }

.empty-state { text-align: center; padding: 1.4rem 0.5rem; color: var(--grey-600); }
.empty-state .icon { font-size: 2.2rem; }
</style>
"""
