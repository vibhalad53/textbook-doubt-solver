"""Helper modules for the Textbook Doubt Solver (prompts and UI styling)."""
