# Screenshots for College Submission

Take these yourself from your own running app and save them in the `screenshots/` folder
with the file names below. **Cover your API key** in any screenshot that might show it.

| # | File name | What to capture |
|---|---|---|
| 1 | `01_project_structure.png` | VS Code Explorer showing the full folder structure |
| 2 | `02_install_requirements.png` | Terminal after `pip install -r requirements.txt` finishes successfully |
| 3 | `03_env_example.png` | `.env.example` file open (never the real `.env`) |
| 4 | `04_app_running_terminal.png` | Terminal showing `streamlit run app.py` and the Local URL |
| 5 | `05_home_page.png` | App home page: header, subtitle, sidebar, upload box |
| 6 | `06_pdf_processing.png` | Status box while/after processing (extract → chunk → embed → index) |
| 7 | `07_pdf_ready.png` | File name pill with page count, chunk count and "Ready to answer" |
| 8 | `08_test1_definition.png` | Test 1 answer with source quote and page number |
| 9 | `09_test2_concept.png` | Test 2 answer |
| 10 | `10_test3_comparison.png` | Test 3 comparison answer |
| 11 | `11_test4_example.png` | Test 4 example answer |
| 12 | `12_test5_not_found.png` | Test 5 "not available in the uploaded textbook" reply |
| 13 | `13_explain_simpler.png` | Original answer and the "Simpler explanation" below it |
| 14 | `14_retrieved_chunks.png` | Expanded "Retrieved textbook chunks" panel |
| 15 | `15_different_pdf.png` | A second, different PDF loaded and answering a question |
| 16 | `16_error_scanned_pdf.png` | Friendly error for a scanned PDF |
| 17 | `17_error_missing_key.png` | Sidebar warning / chat error with no API key |
| 18 | `18_github_repo.png` | Your public GitHub repository page (with no `.env` file visible) |

**Tips:** use full-window screenshots (Windows: `Win + Shift + S`; Mac: `Cmd + Shift + 4`),
keep the browser zoom at 100%, and paste them into your report in the order above.
