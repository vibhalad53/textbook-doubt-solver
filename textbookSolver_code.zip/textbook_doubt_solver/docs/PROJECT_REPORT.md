# Project Procedure Report

**Project:** Textbook Doubt Solver  **Problem Statement No.:** 33  **Roll No.:** 33
**Domain:** Generative AI / Large Language Models  **Language:** Python
**Name:** ______________________  **Class / Division:** ____________  **Date:** ____________

---

## 1. Problem statement

Students get stuck while self-studying and often have nobody to ask. General chatbots
can answer, but they use knowledge from the whole internet, may not match the syllabus,
and sometimes make up facts. The aim of this project is to build an assistant that
answers doubts **using only the uploaded textbook chapter**, shows a **quoted source
line** with its **page number**, and offers an **"Explain Simpler"** follow-up.

## 2. Objectives

1. Accept a textbook chapter in PDF format and extract its text with page numbers.
2. Split the text into chunks, create embeddings and store them in a FAISS vector index.
3. Retrieve the three most relevant chunks for each question.
4. Generate an answer with Google Gemini that relies only on the retrieved chunks.
5. Display a genuine quotation from the PDF and the correct page number.
6. Rewrite answers in simpler language on request.
7. Handle errors (missing key, quota, scanned PDFs, unrelated questions) gracefully.

## 3. Tools and technologies

| Component | Tool | Reason for choice |
|---|---|---|
| Language | Python 3.10+ | Rich AI ecosystem, beginner friendly |
| Frontend | Streamlit | Builds a web UI in pure Python |
| PDF reading | pypdf | Free, page-by-page text extraction |
| Embeddings | Sentence Transformers (all-MiniLM-L6-v2) | Free, runs on CPU, 384-dimension vectors |
| Vector database | FAISS (faiss-cpu) | Fast similarity search, runs locally |
| LLM | Google Gemini API (free tier) | Strong language ability, free key |
| Config | python-dotenv | Keeps the API key out of source code |

## 4. System architecture

The project follows the **Retrieval-Augmented Generation (RAG)** pattern, in two phases.

**Indexing phase (once per PDF):** PDF → page-wise text extraction → chunking
(≈800 characters, 150 overlap, never crossing a page) → embeddings → FAISS index.

**Answering phase (every question):** question → question embedding → FAISS top-3 search
→ prompt (system rules + retrieved chunks + question) → Gemini → JSON reply (answer,
quote, page) → quote verification against the PDF → display.

## 5. Procedure (step by step)

1. **Environment setup:** installed Python, created a virtual environment in VS Code and
   installed the libraries from `requirements.txt`. Obtained a free Gemini API key from
   Google AI Studio and stored it in a `.env` file excluded from Git by `.gitignore`.
2. **PDF text extraction:** `extract_text_from_pdf()` reads each page with pypdf, cleans
   the text (joins hyphen-broken words, removes extra spaces) and stores
   `{page, text}`. If almost no text is found, the PDF is treated as scanned and the user
   is told to use a text-based PDF or OCR.
3. **Chunking:** `split_text_into_chunks()` splits each page at sentence boundaries into
   chunks of about 800 characters, with a 150-character overlap so ideas at chunk edges
   are not lost. Each chunk carries its page number.
4. **Embeddings:** `create_embeddings()` converts every chunk into a normalised
   384-dimensional vector using the all-MiniLM-L6-v2 model.
5. **Vector index:** `build_faiss_index()` stores the vectors in a FAISS `IndexFlatIP`
   index. Because vectors are normalised, inner product equals cosine similarity.
6. **Retrieval:** `retrieve_relevant_chunks()` embeds the student's question and returns
   the top three most similar chunks with their scores and page numbers.
7. **Answer generation:** `generate_answer()` sends a prompt containing the assignment's
   system prompt, the three labelled chunks (`[Source 1 | Page 2]` …) and the question.
   Gemini is asked to reply in JSON with `found`, `answer`, `quote` and `page`.
   Temperature is kept low (0.2) for factual answers.
8. **Quote verification (anti-hallucination step):** the returned quote is normalised and
   searched for word-for-word in the retrieved chunks. If it is found, the page number is
   taken from that chunk's metadata. If not, the closest real sentence is selected
   instead and labelled as auto-selected. No invented quote or page is ever displayed.
9. **Not-found handling:** if the context does not contain the answer, the app shows
   *"This information is not available in the uploaded textbook."* and hides the source box.
10. **Explain Simpler:** `explain_simpler()` sends the previous answer to Gemini with
    instructions to use easier words without changing the meaning or adding information.
11. **User interface:** built with Streamlit: a blue gradient header, sidebar with
    project details and instructions, upload card with processing status, chat bubbles
    for student and AI, a separate source quotation box with page badge, an expandable
    view of the retrieved chunks, and Explain Simpler / Clear Chat buttons.
12. **Testing:** tested with the sample chapter using five question types (definition,
    concept, comparison, example, out-of-syllabus), the Explain Simpler button, a second
    different PDF, and error cases (scanned PDF, missing key). Results are recorded in
    `TEST_CASES.md`.

## 6. Results

*(Fill this in from your own test run. Do not copy the expected outputs as results.)*

- Questions tested: ____  Answered correctly from the textbook: ____
- Out-of-syllabus question correctly refused: Yes / No
- Quotes verified word-for-word: ____ of ____  Page numbers correct: ____ of ____
- Explain Simpler worked: Yes / No  Second PDF processed: Yes / No

## 7. Conclusion

The Textbook Doubt Solver shows how RAG makes a large language model useful and
trustworthy for study. Retrieval keeps answers tied to the student's own chapter, the
system prompt stops the model from using outside knowledge, and the quote-verification
step guarantees that every displayed quotation and page number really comes from the
PDF. The Explain Simpler feature adapts answers to the student's level.

## 8. Limitations and future scope

Scanned PDFs need OCR, tables may extract imperfectly, and the index is kept only in
memory. Future work: OCR support, multiple chapters, follow-up memory, saving indexes,
and auto-generated practice quizzes.
