# Test Cases — Textbook Doubt Solver

**Test document:** `sample_textbook.pdf` (Chapter 5: Photosynthesis, 4 pages)

> The **Expected output** column is what the app *should* do, based on what the sample
> PDF contains. The **Actual output** and **Pass/Fail** columns are for **you** to fill in
> after running the app yourself. Gemini's wording changes slightly every time, so judge
> whether the meaning, quote and page are correct, not the exact words.

## Main question tests

| # | Type | Question to type | Expected output | Actual output | Pass/Fail |
|---|---|---|---|---|---|
| 1 | Basic definition | What is photosynthesis? | Explains that green plants, algae and some bacteria use light energy to turn carbon dioxide and water into glucose and oxygen. Quote from the definition sentence. **Page 1.** | | |
| 2 | Concept explained in chapter | Explain the light-dependent reactions of photosynthesis. | Happen in the thylakoid membranes and need sunlight; chlorophyll absorbs light; water is split (photolysis) releasing oxygen; energy stored in ATP and NADPH. **Page 2.** | | |
| 3 | Comparison | What is the difference between the light-dependent and light-independent reactions? | Compares location (thylakoids vs stroma), need for light, raw materials and products (oxygen/ATP/NADPH vs glucose). Quote likely from the "In short…" sentence or the stage descriptions. **Page 3** (or Page 2). | | |
| 4 | Example | Give an example of photosynthesis that can be seen in a classroom. | Hydrilla water plant giving off oxygen bubbles in bright light (may also mention the iodine starch test). **Page 4.** | | |
| 5 | Not in PDF | Who discovered penicillin? | Exactly: *"This information is not available in the uploaded textbook."* No source quote box shown. | | |

## Feature tests

| # | Feature | Steps | Expected output | Actual output | Pass/Fail |
|---|---|---|---|---|---|
| 6 | Explain Simpler | After test 1, click **✨ Explain Simpler** | A new green-tagged "Simpler explanation" with easier words, same meaning, no new facts; same source quote and page shown | | |
| 7 | Quote is genuine | For tests 1–4, press `Ctrl+F` in the PDF and search for part of the quote | The quoted words exist in the PDF on the page shown | | |
| 8 | Retrieved chunks | Expand "🔍 Retrieved textbook chunks" under an answer | Three chunks with page numbers and similarity scores; the answer is based on them | | |
| 9 | Different PDF | Upload another text-based chapter (any subject) and ask a question about it | Old chat clears; new file name, page and chunk counts shown; answers come from the new PDF | | |
| 10 | Clear Chat | Click **🗑️ Clear Chat** | All messages removed; PDF stays loaded | | |

## Error-handling tests

| # | Situation | Steps | Expected output | Actual output | Pass/Fail |
|---|---|---|---|---|---|
| 11 | Scanned PDF | Upload a PDF made of photos/scans only | Error: "No readable text was found… probably a scanned document…" | | |
| 12 | Missing API key | Rename `.env` to `env_backup`, restart the app, ask a question | Sidebar warning; chat shows "Gemini API key not found…" | | |
| 13 | Wrong API key | Put a wrong key in `.env`, restart, ask a question | "Your Gemini API key was rejected…" | | |
| 14 | Not a PDF | Rename a `.txt` file to `.pdf` and upload it | "This file could not be opened as a PDF…" | | |

## What was checked during development (without a live Gemini key)

These checks were run on the code with stand-in components; they are **not** a
substitute for your own live tests above:

- Text extraction on `sample_textbook.pdf`: 4 pages read, 11 chunks created, every chunk
  ≤ 800 characters and tagged with one page.
- A blank image-only PDF triggers the scanned-PDF message; a fake `.pdf` triggers the
  "could not be opened" message; a second, different PDF is processed independently.
- With a simulated Gemini reply: a genuine quote is accepted and its page is taken from
  the PDF even when the model reports the wrong page; an invented quote is replaced by a
  real sentence from the chapter; a "not found" reply hides the quote; quota, invalid-key,
  missing-key and retired-model errors produce the friendly messages.
