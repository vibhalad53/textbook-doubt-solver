# Viva Questions and Answers — Textbook Doubt Solver

## A. Project basics

**1. What does your project do?**
It lets a student upload a textbook chapter PDF and ask doubts. It answers using only that
chapter, shows a quoted line from the PDF with its page number, and can re-explain the
answer in simpler words.

**2. Why not just use ChatGPT or Gemini directly?**
A general chatbot answers from everything it learned on the internet, so it can go beyond
the syllabus or invent facts. My app gives Gemini only the relevant parts of the student's
own textbook and tells it to answer only from them, with a source the student can check.

**3. What is Generative AI?**
AI that creates new content such as text, images or code, instead of only classifying or
predicting labels. Gemini is a generative model that writes text.

**4. What is a Large Language Model (LLM)?**
A very large neural network (a transformer) trained on huge amounts of text to predict the
next word. Because of this training it can answer questions, summarise and explain.

## B. RAG concepts

**5. What is RAG?**
Retrieval-Augmented Generation. First we **retrieve** relevant text from our own documents,
then we **augment** the prompt with that text, and the LLM **generates** an answer based on
it. It grounds the model in real, specific information.

**6. What are the advantages of RAG over fine-tuning?**
No training is needed, it works with any new PDF instantly, it is free/cheap, the answer
can show its source, and updating knowledge just means uploading a new document.

**7. What is a hallucination and how does your project reduce it?**
A hallucination is when an LLM states something false confidently. I reduce it in four
ways: (1) only retrieved textbook text is given as context, (2) the system prompt forbids
outside knowledge and requires a not-found reply, (3) low temperature (0.2), and (4) my code
checks that the quote really exists in the PDF and takes the page number from the PDF
metadata, not from the model.

**8. What is chunking and why is it needed?**
Splitting long text into small pieces. Embeddings work best on short, focused text, and
sending only a few relevant chunks keeps the prompt small, cheap and focused.

**9. What chunk size and overlap did you use and why?**
About 800 characters with 150 characters of overlap. 800 characters is roughly one
paragraph, big enough to hold an idea but small enough to be specific. The overlap stops
an idea that falls on a chunk boundary from being lost.

**10. How do you keep the correct page number?**
I extract text page by page and never let a chunk cross a page. Each chunk stores its page
number, so whichever chunk the quote comes from tells us the exact page.

**11. Why retrieve the top 3 chunks?**
It was required by the assignment, and it is a good balance: enough context to answer most
questions, but not so much that irrelevant text confuses the model.

## C. Embeddings and FAISS

**12. What is an embedding?**
A list of numbers (a vector) that represents the meaning of text. Texts with similar
meaning get vectors that are close together.

**13. Which embedding model did you use?**
`all-MiniLM-L6-v2` from Sentence Transformers. It is free, small (~90 MB), runs on a normal
CPU and gives 384-dimensional vectors.

**14. What is cosine similarity?**
A measure of how similar two vectors' directions are, from −1 to 1. Higher means more
similar meaning.

**15. What is FAISS?**
Facebook AI Similarity Search, a library from Meta for fast searching of similar vectors.
It acts as the vector database in my project.

**16. Which FAISS index did you use and why?**
`IndexFlatIP` (flat inner-product). It compares the question with every chunk exactly. For
one chapter (tens or hundreds of chunks) exact search is instant. Because my vectors are
normalised, inner product equals cosine similarity.

**17. What is the difference between a vector database and a normal database?**
A normal database finds rows by exact matches (e.g. `name = 'Ravi'`). A vector database
finds items whose meaning is closest to a query vector, even if the words differ.

**18. Can it find an answer if the question uses different words from the book?**
Yes, usually. Semantic embeddings match meaning, so "how do plants make food" can still
retrieve the photosynthesis definition.

## D. Gemini and prompts

**19. Which LLM did you use and how is it called?**
Google Gemini through the official `google-genai` Python SDK. I create a `genai.Client`
with my API key and call `client.models.generate_content()` with the model name, prompt and
a config containing the system instruction and temperature.

**20. What is a system prompt?**
Instructions given to the model that set its role and rules for the whole conversation.
Mine says it is an educational assistant that must use only the textbook context, say
"not available" when needed, explain simply and never invent quotes or page numbers.

**21. What is temperature?**
A setting that controls randomness. Low (0.2) gives focused, consistent, factual answers;
high gives more creative, varied text.

**22. Why do you ask Gemini for JSON output?**
So the answer, quote and page come back as separate fields that my code can verify and
display in separate sections. I also set `response_mime_type="application/json"`.

**23. How does Explain Simpler work?**
It sends the previous answer (not the whole book) to Gemini with instructions to rewrite it
in easier words without changing the meaning or adding new information.

**24. How is the API key kept safe?**
It is stored in a `.env` file loaded with python-dotenv. `.env` is listed in `.gitignore`
so it is never uploaded to GitHub. Only `.env.example` with a placeholder is shared.

## E. Implementation and errors

**25. Why Streamlit?**
It builds an interactive web app using only Python, with ready widgets for file upload,
chat messages, buttons and spinners.

**26. What is `st.session_state` and why do you use it?**
Streamlit re-runs the whole script on every click. Session state remembers data between
re-runs: chat history, the FAISS index and the chunks.

**27. What is `@st.cache_resource`?**
It loads the embedding model only once and reuses it, instead of reloading it on every
click.

**28. What happens with a scanned PDF?**
pypdf finds almost no text, so the app shows a friendly message explaining that the PDF is
probably scanned and needs OCR.

**29. What happens if the question is not in the textbook?**
Gemini returns `found: false`, and the app shows "This information is not available in the
uploaded textbook." with no quote box.

**30. What errors from the Gemini API do you handle?**
Missing key, invalid key, quota/rate limit (429), retired model name (404, with automatic
fallback to another model alias), server errors (5xx), network failures and empty replies.

**31. What if Gemini invents a quote?**
My `_verify_quote()` function searches for the quote word-for-word (ignoring case and
punctuation) in the retrieved chunks. If it isn't found, the code selects the most similar
real sentence from the textbook and labels it as auto-selected.

## F. Limitations and future work

**32. What are the limitations?**
No OCR for scanned PDFs, tables and equations may extract poorly, the index is in memory
only, and the free API tier has rate limits.

**33. How would you improve it?**
Add OCR, support multiple chapters, keep chat memory for follow-up questions, save FAISS
indexes to disk, add hybrid keyword + vector search, and generate practice quizzes.

**34. How would you evaluate answer quality more formally?**
Make a set of questions with known answers and pages, then measure retrieval accuracy (is
the right page in the top 3?), answer correctness, quote validity and not-found accuracy.
